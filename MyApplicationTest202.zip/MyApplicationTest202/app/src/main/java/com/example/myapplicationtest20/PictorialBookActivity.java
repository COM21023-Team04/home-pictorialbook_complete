package com.example.myapplicationtest20;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PictorialBookActivity extends AppCompatActivity {
    TextView BackHome;
    LinearLayout EBenchPress, EPushUp, EDeadlift, EPullUp, EBarbellSquat, ELegExtension;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pictorial_book);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        BackHome = (TextView) findViewById(R.id.BackHome);

        EBenchPress = (LinearLayout) findViewById(R.id.EBenchPress);
        EPushUp = (LinearLayout) findViewById(R.id.EPushUp);
        EDeadlift = (LinearLayout) findViewById(R.id.EDeadlift);
        EPullUp = (LinearLayout) findViewById(R.id.EPullUp);
        EBarbellSquat = (LinearLayout) findViewById(R.id.EBarbellSquat);
        ELegExtension = (LinearLayout) findViewById(R.id.ELegExtension);

        BackHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PictorialBookActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });


        EBenchPress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PictorialBookActivity.this, PB1Activity.class);
                startActivity(intent);
            }
        });

        EPushUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PictorialBookActivity.this, PB2Activity.class);
                startActivity(intent);
            }
        });

        EDeadlift.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PictorialBookActivity.this, PB3Activity.class);
                startActivity(intent);
            }
        });

        EPullUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PictorialBookActivity.this, PB4Activity.class);
                startActivity(intent);
            }
        });

        EBarbellSquat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PictorialBookActivity.this, PB5Activity.class);
                startActivity(intent);
            }
        });

        ELegExtension.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PictorialBookActivity.this, PB6Activity.class);
                startActivity(intent);
            }
        });

    }
}